- database website GIS bukittinggi
- extrak file sql, lalu di phpmyadmin buat database dengan nama qgis_bukittinggi dan import database
- untuk informasi lebih lanjut atau password silahkan hub : owner noHp:0812-4717-9841, kata kunci "password drainase bukittinggi"

((___))
 ‘(++)’-.-.-.-.,
  (.-.)  s p&  ‘:_/’+
    *  ‘-: _:-:_:’     